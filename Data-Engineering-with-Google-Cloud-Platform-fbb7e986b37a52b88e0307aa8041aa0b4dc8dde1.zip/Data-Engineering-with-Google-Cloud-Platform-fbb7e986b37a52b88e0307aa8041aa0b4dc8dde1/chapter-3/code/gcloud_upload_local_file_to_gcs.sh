DESTINATION_BUCKET_NAME=packt-data-eng-on-gcp-data-bucket
gsutil cp chapter-3/dataset/* gs://{$DESTINATION_BUCKET_NAME}/from-git/
