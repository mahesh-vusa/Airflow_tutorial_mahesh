def sum_two_values(arg_1:int , arg_2:int):
    result = arg_1 + arg_2
    return result

if __name__ == "__main__":
    VALUE_1 = 10
    VALUE_2 = 20

    RESULT_VALUE = sum_two_values(VALUE_1, VALUE_2)
    print(RESULT_VALUE)
